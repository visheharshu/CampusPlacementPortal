CAMPUS PLACEMENT PORTAL WITH AI SHORTLISTING
===========================================

SETUP (Windows / VS Code)
1. Extract the ZIP file.
2. Open the extracted CampusPlacementPortal_Final folder in VS Code.
3. Select Terminal > New Terminal.
4. Run:
   python -m pip install -r requirements.txt
5. Run:
   python app.py
6. Open http://127.0.0.1:5000 in Chrome/Edge.

DEMO FLOW
1. Register a Company account with one email address.
2. Log in as Company and post a job. Enter required skills separated by commas, e.g. Python, SQL, HTML.
3. Log out.
4. Register a Student account with a different email address.
5. Log in as Student, open Jobs, apply and upload a resume.
   TXT resumes are read for keyword matching. For PDF/DOC/DOCX, this prototype uses the filename as a fallback score input.
6. Log out and log in as Company to review applications, update status and schedule an interview.
7. Log in as Student to see application status and scheduled interviews.

NOTES
- This is a final-year student project prototype.
- The resume score uses basic keyword matching; it is not a trained AI/ML model.
- Uploaded files are saved in the local uploads folder.
- Data is stored in placement_portal.db, created automatically on first run.
- Do not upload real sensitive personal documents for a demo.
- Before any public deployment, replace the development secret key and add stronger security controls.
